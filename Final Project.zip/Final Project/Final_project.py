import tkinter
from tkinter import *
from tkinter.ttk import *
from PIL import ImageTk, Image
from tkinter import messagebox
import os

class createGraph(Tk):
    """Sets up GUI"""
    def __init__(self):
        self.customize = Tk.__init__(self, className = 'Create a Table')
        
        """Style selection UI"""
        styleLabel = Label(self.customize, text = 'Select a style:')
        styleLabel.grid()
        self.styleVar = StringVar(self.customize," ")
        self.R1 = Radiobutton(self.customize, text = "style 1", variable = self.styleVar, value = 1).grid(row = 1, column = 0)
        self.R2 = Radiobutton(self.customize, text = "style 2", variable = self.styleVar, value = 2).grid(row = 1, column = 1)
        self.styleVar.set(1)

        """Style images"""
        R1Pic = Image.open("Screenshot (57).png")
        R2Pic = Image.open("Screenshot (59).png")
        R1Pic = R1Pic.resize((100,100), Image.LANCZOS)
        R2Pic = R2Pic.resize((100,100), Image.LANCZOS)
        self.R1Pic  = ImageTk.PhotoImage(R1Pic)
        self.R2Pic  = ImageTk.PhotoImage(R2Pic)
        panel = tkinter.Label(self.customize, image = self.R1Pic)
        panel2 = tkinter.Label(self.customize, image = self.R2Pic)
        panel.grid(row = 2, column = 0)
        panel2.grid(row = 2, column = 1)

        """Title, Row, Column, Input Box UI"""
        titleLabel = Label(self.customize, text = 'Enter the title of your graph: ')
        titleLabel.grid(row = 3, column = 0)        
        self.titleVar = StringVar(self.customize," ")
        titleEntry = Entry(self.customize, textvariable = self.titleVar)
        titleEntry.grid(row = 3, column = 1)

        rowLabel = Label(self.customize, text = 'Enter the amount of rows in your graph : ')
        rowLabel.grid(row = 4, column = 0)        
        self.rowVar = StringVar(self.customize," ")
        rowEntry = Entry(self.customize, textvariable = self.rowVar)
        rowEntry.grid(row = 4, column = 1)
        
        columnLabel = Label(self.customize, text = 'Enter the amount of columns in your graph : ')
        columnLabel.grid(row = 5, column = 0)        
        self.columnVar = StringVar(self.customize," ")
        columnEntry = Entry(self.customize, textvariable = self.columnVar)
        columnEntry.grid(row = 5, column = 1)

        """Next button UI"""
        self.nextButton = Button(self.customize, text = 'Next',command = self.nextStep)
        self.nextButton.grid(row = 6, column = 0)

    def fullReset(self):
        """Resets the program"""
        self.next.destroy()
        self.finish.destroy()
                

    def nextStep(self):
        """Creates a new window that allows users to enter data into their table"""
        """Opens table entry window"""
        self.next = Toplevel(self.customize)
        self.tableData = []
        self.cont = True

        """Next window label and button UI"""
        nextLabel = Label(self.next, wraplength = 200, justify = "left", text = 'Each entry box corresponds to a position on your table. Enter in the data for each position on your table in the order you wish for it to appear. Hit the "Finish Table" button when you are finished. Do not use the character "|".')
        nextLabel.grid(row = 0)
        self.finishButton = Button(self.next, text = 'Finish Table', command = self.finishTable)
        self.finishButton.grid(row = 0, column = 1)
        
        """Retrieves number of rows and columns and validates data"""
        try:
            rows = self.rowVar.get()
            self.rows = int(rows)
            columns = self.columnVar.get()
            self.columns = int(columns)
            if self.columns < 1 or self.rows < 1:
                messagebox.showerror("Error", "Columns and rows must be a positive integer")
                self.cont = False
                self.next.destroy()
        except ValueError:
            messagebox.showerror("Error", "Columns and rows must be a positive integer")
            self.next.destroy()
            self.cont = False
      
        """Creates array of entry boxes"""
        if self.cont == True:
            self.tableData = []
            for i in range(self.rows):
                for j in range(self.columns):
                    self.data = Entry(self.next)
                    self.data.grid(row = i + 1, column = j + 1)
                    self.tableData.append(self.data)
                
    def finishTable(self):
        """Retrives data from entry boxes and displays completed table in a new window"""
        if self.cont == True:
            dataList = ''
            for i in self.tableData:
                dataList = dataList + str(i.get() + "|")
            dataList = dataList.split("|")
            dataList.pop()

            """Formats and validates data"""
            try:
                rowList = []
                tableList = []
                while len(dataList) > 0:
                    if len(dataList) != (self.rows * self.columns):
                        tableList.append(rowList)
                    rowList = []
                    for i in range(self.columns):
                        data = dataList.pop(0)
                        if len(data) > 20:
                            messagebox.showerror("Error",  "Entry must be under 21 characters")
                            self.cont = False
                        rowList.append(data)
                tableList.append(rowList)
                headerList = tableList.pop(0)
            except IndexError:
                messagebox.showerror("Error", "Don't use the character '|'")
                self.cont = False
            
            """Retrieves title and style selection"""
            title = self.titleVar.get()
            style = self.styleVar.get()

            """Validates title data"""
            if len(title) > 40:
                messagebox.showerror("Error", "Title must be under 41 characters")
                self.cont = False
            
            """Opens new window and displays table"""
            if self.cont == True:
                self.finish = Toplevel(self.customize)
                from tabulate import tabulate
                if style == '1':
                    table = tabulate(tableList, headers = headerList, tablefmt = "orgtbl")
                elif style == '2':
                    table = tabulate(tableList, headers = headerList, tablefmt = "outline") 

                """New window UI"""
                tableLabel = Label(self.finish, text = table, font = ("Courier New",14))
                titleLabel = Label(self.finish, text = title, font = ("Courier New",16))
                titleLabel.grid(row = 0)
                tableLabel.grid(row = 1)
                self.resetButton = Button(self.finish, text = 'Reset', command = self.fullReset)
                self.resetButton.grid(row = 2)
                
def main():
    """Bring up window"""
    createGraph().mainloop()
if __name__ == "__main__":
    main()
